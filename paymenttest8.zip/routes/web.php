<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\NagadController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::get('/nagad/pay',[NagadController::class,'pay'])->name('nagad.pay');
Route::get('/nagad/callback', [NagadController::class,'callback']);
Route::get('/nagad/refund/{paymentRefId}', [NagadController::class,'refund']);


//payment
Route::get('payment', [App\Http\Controllers\PaymentController::class, 'payment'])->name('payment');